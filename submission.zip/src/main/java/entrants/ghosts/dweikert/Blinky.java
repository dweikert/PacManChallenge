package entrants.ghosts.dweikert;


import pacman.game.Constants;

/**
 * Created by Piers on 11/11/2015.
 */
public class Blinky extends NeuralGhosts {


    public Blinky() {
        super(Constants.GHOST.BLINKY, 50);
    }

}
