package examples.StarterGhost;

import pacman.game.Constants;

/**
 * Created by Piers on 11/11/2015.
 */
public class Pinky extends POGhost {

    public Pinky() {
        super(Constants.GHOST.PINKY);
    }

}
